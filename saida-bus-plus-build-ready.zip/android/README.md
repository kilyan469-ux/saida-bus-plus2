# مشروع Saida Bus Plus لنظام Android 12 وما فوق

هذا الدليل يشرح كيفية بناء حزمة APK كاملة وتجربتها على هاتف يعمل بنظام **Android 12**.

---

## 1. المتطلبات الأساسية (Prerequisites)
1. تثبيت **Android Studio Hedgehog أو Iguana أو أحدث** (أو تثبيت Android SDK 34 سطر أوامر).
2. Java Development Kit (JDK 17).
3. تفعيل وضع تصحيح أخطاء USB (USB Debugging) على هاتفك Android 12.

---

## 2. خطوات البناء عبر Android Studio
1. افتح برنامج **Android Studio**.
2. اختر **Open** ثم حدد مجلد `android` من هذا المشروع.
3. انتظر اكتمال مزامنة Gradle (Gradle Sync).
4. من القائمة العلوية اضغط على:
   `Build` > `Build Bundle(s) / APK(s)` > `Build APK(s)`
5. سيتم إنشاء الملف في المسار:
   `android/app/build/outputs/apk/debug/app-debug.apk`

---

## 3. خطوات البناء عبر سطر الأوامر (Terminal / CLI)

```bash
# الانتقال لمجلد أندرويد
cd android

# إعطاء صلاحية التشغيل لمجمع Gradle
chmod +x gradlew

# بناء حزمة APK بنمط Debug
./gradlew assembleDebug

# تثبيت الحزمة مباشرة على هاتف Android 12 المتصل
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

---

## 4. الميزات الخاصة بـ Android 12 (API 31+)
* **`android:exported="true"`**: مضافة إلزامياً في `AndroidManifest.xml` للنشاط الرئيسي `MainActivity` لمنع تعذر التثبيت على Android 12.
* **إذن الموقع الدقيق والتقريبي**: يدعم التطبيق كلا الإذنين `ACCESS_FINE_LOCATION` و `ACCESS_COARSE_LOCATION` لضمان الحصول على موقع المستخدم حتى في حال اختيار "الموقع التقريبي" في إعدادات خصوصية Android 12.
* **مسرع العتاد (Hardware Acceleration)**: مفعّل افتراضياً لضمان سلاسة الخريطة وتحريك الحافلات بمعدل 60 إطار في الثانية دون استهلاك زائد للبطارية.

---

## 5. التثبيت السريع كـ PWA (بدون حاسوب)
يمكنك أيضاً فتح رابط التطبيق مباشرة من هاتف Android 12 في متصفح Chrome:
1. افتح رابط التطبيق.
2. اضغط على خيارات المتصفح (⋮).
3. اختر **"تثبيت التطبيق" (Install App)**.
سيتم تثبيت التطبيق وتثبيت أيقونته فورياً كـ تطبيق محلي مستقل.
